# 💚 Health Tracker - Трекер здоровья

Fullstack приложение для отслеживания здоровья: сон, питание, потребление воды и физическая активность.

## 🚀 Технологии

### Backend
- Node.js
- Express.js
- MongoDB
- Mongoose
- JWT Authentication
- bcryptjs

### Frontend
- HTML5
- CSS3
- JavaScript (Vanilla)
- LocalStorage

## 📋 Функциональность

- ✅ Регистрация и авторизация пользователей
- ✅ Настройка профиля (возраст, пол, рост, вес, активность)
- ✅ Учет сна (время, продолжительность, качество)
- ✅ Учет потребления воды
- ✅ Учет физической активности (шаги)
- ✅ Учет питания (завтрак, обед, ужин)
- ✅ Дашборд с общей статистикой
- ✅ Статистика за период (неделя, месяц, год)
- ✅ Постановка и отслеживание целей
- ✅ Персональные рекомендации
- ✅ Экспорт данных

## 🛠️ Установка и запуск

### Требования
- Node.js (v14+)
- MongoDB (v4.4+)
- Современный браузер

### Backend

1. Перейдите в папку backend:
```bash
cd backend
```

2. Установите зависимости:
```bash
npm install
```

3. Создайте файл `.env` в папке backend:
```env
PORT=5000
MONGODB_URI=mongodb://localhost:27017/health_tracker
JWT_SECRET=your_jwt_secret_key_change_this_in_production
JWT_EXPIRE=30d
```

4. Запустите MongoDB:
```bash
# Windows
net start MongoDB

# macOS/Linux
sudo systemctl start mongod
```

5. Запустите сервер:
```bash
npm start
```

Сервер запустится на `http://localhost:5000`

### Frontend

1. Перейдите в папку frontend:
```bash
cd frontend
```

2. Откройте `index.html` в браузере или используйте Live Server

**Вариант 1: Двойной клик**
- Откройте `index.html` двойным кликом

**Вариант 2: Live Server (VS Code)**
- Установите расширение "Live Server"
- Правой кнопкой на `index.html` → "Open with Live Server"

**Вариант 3: HTTP Server**
```bash
npx http-server -p 8000
```

Откройте `http://localhost:8000`

## 📁 Структура проекта
```
health-tracker-fullstack/
├── backend/
│   ├── config/
│   │   └── db.js                    # Конфигурация MongoDB
│   ├── controllers/
│   │   ├── authController.js        # Авторизация
│   │   ├── goalsController.js       # Цели
│   │   ├── mealsController.js       # Питание
│   │   ├── profileController.js     # Профиль
│   │   ├── sleepController.js       # Сон
│   │   ├── statisticsController.js  # Статистика
│   │   ├── stepsController.js       # Шаги
│   │   └── waterController.js       # Вода
│   ├── middleware/
│   │   └── auth.js                  # JWT middleware
│   ├── models/
│   │   ├── Goal.js                  # Модель целей
│   │   ├── Meal.js                  # Модель питания
│   │   ├── Sleep.js                 # Модель сна
│   │   ├── Steps.js                 # Модель шагов
│   │   ├── User.js                  # Модель пользователя
│   │   └── Water.js                 # Модель воды
│   ├── routes/
│   │   ├── auth.js                  # Маршруты авторизации
│   │   ├── goals.js                 # Маршруты целей
│   │   ├── meals.js                 # Маршруты питания
│   │   ├── profile.js               # Маршруты профиля
│   │   ├── sleep.js                 # Маршруты сна
│   │   ├── statistics.js            # Маршруты статистики
│   │   ├── steps.js                 # Маршруты шагов
│   │   └── water.js                 # Маршруты воды
│   ├── .env                         # Переменные окружения
│   ├── package.json                 # Зависимости backend
│   └── server.js                    # Главный файл сервера
├── frontend/
│   ├── css/
│   │   └── style.css                # Основные стили
│   ├── js/
│   │   └── main.js                  # Основная логика
│   ├── advice.html                  # Рекомендации
│   ├── dashboard.html               # Дашборд
│   ├── food.html                    # Учет питания
│   ├── goals.html                   # Цели
│   ├── index.html                   # Главная страница
│   ├── login.html                   # Вход
│   ├── profile-setup.html           # Настройка профиля
│   ├── profile.html                 # Профиль пользователя
│   ├── sleep.html                   # Учет сна
│   ├── statistics.html              # Статистика
│   ├── steps.html                   # Учет шагов
│   └── water.html                   # Учет воды
├── .gitignore                       # Игнорируемые файлы
└── README.md                        # Документация
```

## 🔐 API Endpoints

### Авторизация
```
POST /api/auth/register              # Регистрация
POST /api/auth/login                 # Вход
```

### Профиль
```
GET  /api/profile                    # Получить профиль
PUT  /api/profile                    # Обновить профиль
```

### Сон
```
POST /api/sleep                      # Добавить данные о сне
GET  /api/sleep?date=YYYY-MM-DD      # Получить данные за день
GET  /api/sleep/history              # История сна
```

### Вода
```
POST /api/water                      # Добавить воду
GET  /api/water?date=YYYY-MM-DD      # Получить данные за день
GET  /api/water/history              # История потребления
```

### Шаги
```
POST /api/steps                      # Добавить шаги
GET  /api/steps?date=YYYY-MM-DD      # Получить данные за день
GET  /api/steps/history              # История активности
```

### Питание
```
POST   /api/meals                    # Добавить прием пищи
GET    /api/meals?date=YYYY-MM-DD    # Получить данные за день
DELETE /api/meals/:id                # Удалить прием пищи
GET    /api/meals/history            # История питания
```

### Цели
```
POST   /api/goals                    # Создать/обновить цель
GET    /api/goals                    # Получить все цели
DELETE /api/goals/:id                # Удалить цель
```

### Статистика
```
GET /api/statistics/dashboard        # Данные для дашборда
GET /api/statistics?type=sleep&startDate=YYYY-MM-DD&endDate=YYYY-MM-DD
```

## 👤 Использование

1. **Регистрация**: Создайте аккаунт на главной странице
2. **Настройка профиля**: Укажите возраст, пол, рост, вес, активность
3. **Дашборд**: Просматривайте общую статистику здоровья
4. **Добавление данных**: Записывайте сон, воду, шаги, питание
5. **Цели**: Устанавливайте и отслеживайте свои цели
6. **Статистика**: Анализируйте прогресс за неделю/месяц/год
7. **Рекомендации**: Получайте персональные советы

## 🎨 Особенности дизайна

- Минималистичный зеленый интерфейс
- Адаптивный дизайн для всех устройств
- Интуитивная навигация
- Визуальные индикаторы прогресса
- Анимированные уведомления

## 🔧 Возможные улучшения

- [ ] Графики и диаграммы (Chart.js)
- [ ] Push-уведомления
- [ ] Интеграция с фитнес-трекерами
- [ ] Социальные функции (друзья, соревнования)
- [ ] Мобильное приложение
- [ ] Темная тема
- [ ] Мультиязычность
- [ ] AI-рекомендации на основе данных
